﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Customer.Models;

namespace Customer.Controllers
{
    public class HomeController : Controller
    {
        CustomersController db = new CustomersController();

        public ActionResult Index()
        {
            return View(db.Get());
        }

        //
        // GET: /Home/Details/5

        public ActionResult Details(int id = 0)
        {
            CustomerModel customer = db.Get(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        //
        // GET: /Home/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Home/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CustomerModel customer)
        {
            if (ModelState.IsValid)
            {
                List<string> customerList = new List<string>();
                customerList.Add(customer.name);
                customerList.Add(customer.email);
                customerList.Add(customer.contact_number);
                db.Post(customerList);
                return RedirectToAction("Index");
            }

            return View(customer);
        }

        //
        // GET: /Home/Edit/5

        public ActionResult Edit(int id = 0)
        {
            CustomerModel customer = db.Get(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        //
        // POST: /Home/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, CustomerModel customer)
        {
            if (ModelState.IsValid)
            {
                db.Put(id, customer);
                return RedirectToAction("Index");
            }
            return View(customer);
        }

        //
        // GET: /Home/Delete/5

        public ActionResult Delete(int id = 0)
        {
            CustomerModel customer = db.Get(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        //
        // POST: /Home/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            db.Delete(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}
