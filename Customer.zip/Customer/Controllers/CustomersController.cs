﻿using Customer.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;

namespace Customer.Controllers
{
    public class CustomersController : ApiController
    {
        private CustomerContext db = new CustomerContext();

        public IEnumerable<CustomerModel> Get()
        {
            return db.Customers.ToList();
        }

        // GET api/values/5
        public CustomerModel Get(int id)
        {
            return db.Customers.Find(id);
            //return 'value';
        }
        // POST api/values
        public void Post(List<string> val )   {
            try
            {
                CustomerModel obj = new CustomerModel();
                obj.name = val[0];
                obj.email = val[1];
                obj.contact_number = val[2];
                db.Customers.Add(obj);
                db.SaveChanges();
            }
            catch (Exception ex) { }
        }
        // PUT api/values/5
        public void Put(int id, CustomerModel obj)
        {
            try
            {
                db.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
            catch (Exception) { }
        }
        //This method for update through Json
        public void Put(List<string> val)
        {
            try
            {
                int id = Convert.ToInt32(val[3]);
                CustomerModel obj = db.Customers.Find(id);
                obj.name = val[0];
                obj.email = val[1];
                obj.contact_number = val[2];
                db.Customers.Add(obj);
                db.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
            catch (Exception) { }
        }
        // DELETE api/values/5
        public void Delete(int id)
        {
            CustomerModel obj = db.Customers.Find(id);
            db.Customers.Remove(obj);
            db.SaveChanges();
        }
    }
}